/* Main JavaScript for ILM Website */

document.addEventListener('DOMContentLoaded', function() {
    // Header scroll effect
    const header = document.querySelector('header');
    const scrollToTopBtn = document.querySelector('.scroll-to-top');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            header.classList.add('header-scrolled');
            scrollToTopBtn.classList.add('active');
        } else {
            header.classList.remove('header-scrolled');
            scrollToTopBtn.classList.remove('active');
        }
    });
    
    // Mobile navigation toggle
    const mobileNavToggle = document.querySelector('.mobile-nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (mobileNavToggle) {
        mobileNavToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            this.innerHTML = navMenu.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                if (navMenu.classList.contains('active')) {
                    navMenu.classList.remove('active');
                    mobileNavToggle.innerHTML = '<i class="fas fa-bars"></i>';
                }
            }
        });
    });
    
    // Scroll to top button
    if (scrollToTopBtn) {
        scrollToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
    
    // Video thumbnails click handler
    const videoThumbnails = document.querySelectorAll('.video-thumbnail');
    const mainVideoContainer = document.querySelector('.video-container iframe');
    
    if (videoThumbnails.length > 0 && mainVideoContainer) {
        videoThumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', function() {
                const videoId = this.getAttribute('data-video-id');
                if (videoId) {
                    mainVideoContainer.src = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
                    
                    // Scroll to main video
                    window.scrollTo({
                        top: document.querySelector('.video-container').offsetTop - 100,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }
    
    // Testimonial slider
    let currentTestimonial = 0;
    const testimonials = document.querySelectorAll('.testimonial-item');
    const testimonialDots = document.querySelectorAll('.testimonial-dot');
    
    if (testimonials.length > 0) {
        // Initialize testimonial display
        showTestimonial(currentTestimonial);
        
        // Auto-advance testimonials
        setInterval(() => {
            currentTestimonial = (currentTestimonial + 1) % testimonials.length;
            showTestimonial(currentTestimonial);
        }, 5000);
        
        // Dot navigation
        if (testimonialDots.length > 0) {
            testimonialDots.forEach((dot, index) => {
                dot.addEventListener('click', () => {
                    currentTestimonial = index;
                    showTestimonial(currentTestimonial);
                });
            });
        }
        
        function showTestimonial(index) {
            testimonials.forEach((testimonial, i) => {
                testimonial.style.display = i === index ? 'block' : 'none';
            });
            
            if (testimonialDots.length > 0) {
                testimonialDots.forEach((dot, i) => {
                    dot.classList.toggle('active', i === index);
                });
            }
        }
    }
    
    // Animation on scroll
    const animatedElements = document.querySelectorAll('.animate');
    
    if (animatedElements.length > 0) {
        checkAnimation();
        window.addEventListener('scroll', checkAnimation);
        
        function checkAnimation() {
            animatedElements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                
                if (elementPosition < windowHeight - 50) {
                    element.classList.add('animated');
                }
            });
        }
    }
});
